package com.techcode.agent

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private sealed interface DiffItem {
    data class Header(val path: String, val isNew: Boolean, val add: Int, val del: Int) : DiffItem
    data class Line(val line: DLine) : DiffItem
    data object Gap : DiffItem
    data object Spacer : DiffItem
}

private fun buildDiffItems(cs: ChangeSet): List<DiffItem> {
    val out = ArrayList<DiffItem>()
    for (f in cs.files) {
        val lines = diffLines(f.oldContent, f.newContent)
        val add = lines.count { it.type == DType.ADD }
        val del = lines.count { it.type == DType.DEL }
        out.add(DiffItem.Header(f.path, f.oldContent == null, add, del))
        for (row in collapseContext(lines)) {
            out.add(if (row == null) DiffItem.Gap else DiffItem.Line(row))
        }
        out.add(DiffItem.Spacer)
    }
    return out
}

@Composable
fun DiffScreen(vm: AppViewModel, csId: String) {
    val cs = vm.changeSets[csId]
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .systemBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.closeDiff() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Wapas", tint = TC.Navy)
            }
            Column(Modifier.weight(1f)) {
                Text("Changes review karo", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TC.Navy)
                if (cs != null) {
                    Text("${cs.files.size} file${if (cs.files.size == 1) "" else "s"}", fontSize = 12.sp, color = TC.Muted)
                }
            }
        }
        HorizontalDivider(color = TC.Border)

        if (cs == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = TC.Blue)
            }
            return@Column
        }

        val items by produceState<List<DiffItem>?>(null, cs.id) {
            value = withContext(Dispatchers.Default) { buildDiffItems(cs) }
        }

        val list = items
        if (list == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = TC.Blue)
            }
        } else {
            LazyColumn(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
            ) {
                if (cs.summary.isNotBlank()) {
                    item {
                        Text(
                            cs.summary,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            maxLines = 8,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(TC.Card)
                                .border(1.dp, TC.Border, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        )
                    }
                }
                items(list) { d ->
                    when (d) {
                        is DiffItem.Header -> FileHeader(d)
                        is DiffItem.Line -> DiffRow(d.line)
                        DiffItem.Gap -> Text(
                            "···",
                            color = TC.Muted,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TC.Soft)
                                .padding(start = 40.dp, top = 2.dp, bottom = 2.dp)
                        )
                        DiffItem.Spacer -> Spacer(Modifier.height(16.dp))
                    }
                }
            }
        }

        HorizontalDivider(color = TC.Border)
        ActionBar(vm, cs)
    }
}

@Composable
private fun FileHeader(h: DiffItem.Header) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
            .background(TC.Soft)
            .border(1.dp, TC.Border, RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            h.path,
            modifier = Modifier.weight(1f),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
            color = TC.Navy,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (h.isNew) {
            Text(
                "NEW",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TC.AddFg,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(TC.AddBg)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
        Text("+${h.add}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace, color = TC.Green)
        Text("−${h.del}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace, color = TC.Red)
    }
}

@Composable
private fun DiffRow(l: DLine) {
    val bg: Color
    val fg: Color
    val mark: String
    when (l.type) {
        DType.ADD -> {
            bg = TC.AddBg; fg = TC.AddFg; mark = "+"
        }
        DType.DEL -> {
            bg = TC.DelBg; fg = TC.DelFg; mark = "−"
        }
        DType.SAME -> {
            bg = Color.Transparent; fg = Color(0xFF1E293B); mark = " "
        }
    }
    val number = if (l.type == DType.DEL) l.oldNo else l.newNo
    Row(
        Modifier
            .fillMaxWidth()
            .background(bg)
    ) {
        Text(
            number.toString(),
            modifier = Modifier
                .width(40.dp)
                .padding(end = 8.dp),
            textAlign = TextAlign.End,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            lineHeight = 20.sp,
            color = if (l.type == DType.SAME) TC.Muted else fg
        )
        Text(
            "$mark ${l.text}",
            modifier = Modifier.weight(1f),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.5.sp,
            lineHeight = 20.sp,
            color = fg,
            fontWeight = if (l.type == DType.SAME) FontWeight.Normal else FontWeight.Medium
        )
    }
}

@Composable
private fun ActionBar(vm: AppViewModel, cs: ChangeSet) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(top = 12.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        when (cs.status) {
            ChangeStatus.PENDING -> {
                Text(
                    "Approve se pehle purana content save ho jayega, baad mein Undo kar sakte ho.",
                    fontSize = 12.5.sp, color = TC.Muted
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { vm.reject(cs.id) },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        shape = RoundedCornerShape(26.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TC.Red)
                    ) {
                        Icon(Icons.Default.Close, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Reject", fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { vm.approve(cs.id) },
                        modifier = Modifier
                            .weight(1.4f)
                            .height(52.dp),
                        shape = RoundedCornerShape(26.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TC.Blue, contentColor = Color.White)
                    ) {
                        Icon(Icons.Default.Check, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Approve", fontWeight = FontWeight.Bold)
                    }
                }
            }

            ChangeStatus.APPLIED -> {
                Text("Ye changes apply ho chuke hain.", fontSize = 13.sp, color = TC.Green, fontWeight = FontWeight.SemiBold)
                OutlinedButton(
                    onClick = { vm.undo(cs.id) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TC.Navy)
                ) {
                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Undo", fontWeight = FontWeight.Bold)
                }
            }

            ChangeStatus.REJECTED -> Text("Ye changes reject kiye gaye the.", fontSize = 13.sp, color = TC.Muted)
            ChangeStatus.UNDONE -> Text("Ye changes undo ho chuke hain.", fontSize = 13.sp, color = TC.Muted)
        }
    }
}
