package com.techcode.agent

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s = vm.settings
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .systemBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.screen = Screen.Chat }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Wapas", tint = TC.Navy)
            }
            Text("Settings", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TC.Navy)
        }
        HorizontalDivider(color = TC.Border)

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Gemini API keys", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TC.Navy)
            Text(
                "Testing build: 4 keys daalo, har role ko apni key milegi (UI, Logic, Merge, Verify). " +
                    "Single mode mein sirf Key 1 use hoti hai. Koi slot khaali ho to pehli bhari hui key use hogi. " +
                    "Keys sirf is phone mein save hoti hain.",
                fontSize = 13.sp, color = TC.Muted, lineHeight = 19.sp
            )
            ROLE_NAMES.forEachIndexed { i, role ->
                KeyField(
                    label = "Key ${i + 1} ($role)",
                    value = s.keys[i],
                    onChange = { v ->
                        vm.updateSettings { st -> st.copy(keys = st.keys.mapIndexed { j, old -> if (j == i) v.trim() else old }) }
                    }
                )
            }
            Text(
                "Key yahan se milti hai: aistudio.google.com/apikey",
                fontSize = 12.sp, color = TC.Muted, fontFamily = FontFamily.Monospace
            )

            HorizontalDivider(color = TC.Border)

            Text("Project instructions", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TC.Navy)
            Text(
                "Apne project folder mein TECHCODE.md naam ki file bana do. AI har baar use padhega (CLAUDE.md bhi chalega).",
                fontSize = 13.sp, color = TC.Muted, lineHeight = 19.sp
            )

            HorizontalDivider(color = TC.Border)

            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(TC.Card)
                    .border(1.dp, TC.Border, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("TechCode 0.1.0 (testing)", fontWeight = FontWeight.SemiBold, color = TC.Navy)
                Text("Abhi login nahi hai. Agent code run nahi kar sakta, sirf files padhta aur badalta hai.", fontSize = 12.sp, color = TC.Muted)
            }
        }
    }
}

@Composable
private fun KeyField(label: String, value: String, onChange: (String) -> Unit) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
            IconButton(onClick = { show = !show }) {
                Icon(
                    if (show) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = if (show) "Chhupao" else "Dikhao",
                    tint = TC.Muted
                )
            }
        },
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = TC.Blue,
            focusedLabelColor = TC.Blue,
            cursorColor = TC.Blue
        )
    )
}
