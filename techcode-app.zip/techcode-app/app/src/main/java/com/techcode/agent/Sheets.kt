@file:OptIn(ExperimentalMaterial3Api::class)

package com.techcode.agent

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ------------------------------------------------------------------ model & mode

@Composable
fun ModelSheet(vm: AppViewModel, onDismiss: () -> Unit, onOpenSettings: () -> Unit) {
    val s = vm.settings
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color.White) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Mode", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TC.Navy)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModeButton("Single model", s.mode == Mode.SINGLE, Modifier.weight(1f)) {
                    vm.updateSettings { it.copy(mode = Mode.SINGLE) }
                }
                ModeButton("Team (4 models)", s.mode == Mode.TEAM, Modifier.weight(1f)) {
                    vm.updateSettings { it.copy(mode = Mode.TEAM) }
                }
            }

            if (s.mode == Mode.SINGLE) {
                Text("Ek model sab kaam karta hai (Key 1 use hoti hai). Kabhi bhi badal sakte ho.", fontSize = 13.sp, color = TC.Muted)
                ModelPicker(s.singleModel) { m -> vm.updateSettings { it.copy(singleModel = m) } }
            } else {
                Text(
                    "UI aur Logic saath mein kaam karte hain, Merge dono ko jodta hai, Verify check karta hai aur galti mile to wapas bhejta hai.",
                    fontSize = 13.sp, color = TC.Muted, lineHeight = 18.sp
                )
                val desc = listOf(
                    "Layout, screens, styling",
                    "Functions, data, API",
                    "Dono ka kaam jodta hai",
                    "Review karta hai, bugs wapas bhejta hai"
                )
                ROLE_NAMES.forEachIndexed { i, role ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(TC.Card)
                            .border(1.dp, TC.Border, RoundedCornerShape(14.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(role, fontWeight = FontWeight.Bold, color = TC.Navy, fontSize = 15.sp)
                                Text(desc[i], fontSize = 12.sp, color = TC.Muted)
                            }
                            Text(
                                if (s.keys[i].isBlank()) "Key ${i + 1}: khaali" else "Key ${i + 1}: set",
                                fontSize = 12.sp,
                                color = if (s.keys[i].isBlank()) TC.Red else TC.Green,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        ModelPicker(s.models[i]) { m ->
                            vm.updateSettings { st -> st.copy(models = st.models.mapIndexed { j, old -> if (j == i) m else old }) }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Verify retries", fontWeight = FontWeight.SemiBold, color = TC.Navy)
                        Text("Verifier galti bheje to kitni baar fix karwana hai", fontSize = 12.sp, color = TC.Muted)
                    }
                    IconButton(onClick = { vm.updateSettings { it.copy(maxRetries = (it.maxRetries - 1).coerceAtLeast(0)) } }) {
                        Icon(Icons.Default.Remove, contentDescription = "Kam", tint = TC.Navy)
                    }
                    Text("${s.maxRetries}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TC.Navy)
                    IconButton(onClick = { vm.updateSettings { it.copy(maxRetries = (it.maxRetries + 1).coerceAtMost(5)) } }) {
                        Icon(Icons.Default.Add, contentDescription = "Zyada", tint = TC.Navy)
                    }
                }
            }
            TextButton(onClick = onOpenSettings) { Text("API keys / Settings", color = TC.Blue) }
        }
    }
}

@Composable
private fun ModeButton(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    if (selected) {
        Button(
            onClick = onClick,
            modifier = modifier,
            colors = ButtonDefaults.buttonColors(containerColor = TC.Blue, contentColor = Color.White)
        ) { Text(label, fontSize = 13.sp, maxLines = 1) }
    } else {
        OutlinedButton(
            onClick = onClick,
            modifier = modifier,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TC.Navy)
        ) { Text(label, fontSize = 13.sp, maxLines = 1) }
    }
}

@Composable
fun ModelPicker(value: String, onChange: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MODEL_PRESETS.forEach { m ->
                FilterChip(
                    selected = value == m,
                    onClick = { onChange(m) },
                    label = { Text(m, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TC.Blue,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            label = { Text("Model name (custom bhi likh sakte ho)") },
            singleLine = true,
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = TC.Blue,
                focusedLabelColor = TC.Blue,
                cursorColor = TC.Blue
            )
        )
    }
}

// ------------------------------------------------------------------ files

@Composable
fun FilesSheet(vm: AppViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val project = vm.currentProject
    var viewing by remember { mutableStateOf<String?>(null) }

    if (project == null) return

    val files by produceState<List<String>?>(null, project.id) {
        value = withContext(Dispatchers.IO) {
            runCatching { ProjectFiles(ctx, Uri.parse(project.folderUri)).listAll() }.getOrDefault(emptyList())
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color.White) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text("Project files", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TC.Navy)
            Spacer(Modifier.size(8.dp))
            val list = files
            when {
                list == null -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = TC.Blue)
                }
                list.isEmpty() -> Text("Folder khaali hai ya padh nahi pa raha.", color = TC.Muted, fontSize = 14.sp)
                else -> LazyColumn(Modifier.heightIn(max = 480.dp)) {
                    items(list, key = { it }) { path ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(enabled = isTextPath(path)) { viewing = path }
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Description, null, tint = TC.Blue, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    path.substringAfterLast('/'),
                                    fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = TC.Navy,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                if (path.contains('/')) {
                                    Text(
                                        path.substringBeforeLast('/'),
                                        fontSize = 11.sp, color = TC.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    viewing?.let { path ->
        val content by produceState<String?>(null, path) {
            value = withContext(Dispatchers.IO) {
                runCatching { ProjectFiles(ctx, Uri.parse(project.folderUri)).readText(path) }.getOrNull() ?: "(padh nahi paya)"
            }
        }
        AlertDialog(
            onDismissRequest = { viewing = null },
            title = { Text(path, fontFamily = FontFamily.Monospace, fontSize = 14.sp, color = TC.Navy) },
            text = {
                Box(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    Text(
                        (content ?: "Loading...").take(20_000),
                        fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 18.sp
                    )
                }
            },
            confirmButton = { TextButton(onClick = { viewing = null }) { Text("Close") } }
        )
    }
}

// ------------------------------------------------------------------ new project

@Composable
fun NewProjectDialog(onDismiss: () -> Unit, onCreate: (String, String) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var folderLabel by remember { mutableStateOf("") }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { picked ->
        if (picked != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    picked,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            uri = picked
            folderLabel = DocumentFile.fromTreeUri(ctx, picked)?.name ?: "folder"
            if (name.isBlank()) name = folderLabel
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New project", color = TC.Navy, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Project ka naam") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TC.Blue,
                        focusedLabelColor = TC.Blue,
                        cursorColor = TC.Blue
                    )
                )
                OutlinedButton(
                    onClick = { launcher.launch(null) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TC.Navy)
                ) {
                    Icon(Icons.Default.Folder, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (uri == null) "Folder chuno" else folderLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(
                    "AI sirf isi folder ke andar kaam karega. Android 11+ mein Download ya storage ka root allowed nahi, uske andar ka koi folder chuno.",
                    fontSize = 12.sp, color = TC.Muted, lineHeight = 17.sp
                )
            }
        },
        confirmButton = {
            TextButton(enabled = uri != null, onClick = { onCreate(name, uri.toString()) }) {
                Text("Create", color = if (uri != null) TC.Blue else TC.Muted, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = TC.Muted) } }
    )
}
