package com.techcode.agent

/**
 * A staging layer on top of the real folder. Agents "write" here; nothing touches the
 * user's files until they approve the final change set.
 */
class Workspace(private val files: ProjectFiles, val baseList: List<String>) {
    private val staged = LinkedHashMap<String, String>()

    fun read(path: String): String? {
        val p = normPath(path)
        synchronized(this) { staged[p]?.let { return it } }
        return files.readText(p)
    }

    fun base(path: String): String? = files.readText(normPath(path))

    fun write(path: String, content: String) {
        synchronized(this) { staged[normPath(path)] = content }
    }

    fun proposals(): Map<String, String> = synchronized(this) { LinkedHashMap(staged) }

    fun allFiles(): List<String> {
        val extra = synchronized(this) { staged.keys.toList() }
        return (baseList + extra).distinct().sorted()
    }

    fun search(query: String, limit: Int = 40): List<String> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        val hits = ArrayList<String>()
        for (path in allFiles()) {
            if (hits.size >= limit) break
            if (!isTextPath(path)) continue
            val text = read(path) ?: continue
            if (text.length > 300_000) continue
            val lines = text.split("\n")
            for ((i, line) in lines.withIndex()) {
                if (line.lowercase().contains(q)) {
                    hits.add("$path:${i + 1}: ${line.trim().take(160)}")
                    if (hits.size >= limit) break
                }
            }
        }
        return hits
    }

    fun copyProposalsFrom(other: Workspace, only: Set<String>? = null) {
        for ((p, c) in other.proposals()) {
            if (only == null || p in only) write(p, c)
        }
    }
}
