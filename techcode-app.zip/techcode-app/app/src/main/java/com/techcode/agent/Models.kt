package com.techcode.agent

import java.util.UUID

fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(12)

const val DEFAULT_MODEL = "gemini-2.5-flash"
val MODEL_PRESETS = listOf("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.5-flash-lite", "gemini-2.0-flash")

/** Slot 0 = UI, 1 = Logic, 2 = Merge, 3 = Verify. */
val ROLE_NAMES = listOf("UI", "Logic", "Merge", "Verify")

data class Project(val id: String, val name: String, val folderUri: String, val createdAt: Long)

data class Chat(val id: String, val projectId: String, val title: String, val updatedAt: Long)

enum class Kind { USER, AI, TOOL, CHANGES, ERROR }

data class ChatItem(
    val id: String = newId(),
    val kind: Kind,
    val text: String = "",
    /** TOOL: file path or query. */
    val sub: String = "",
    /** CHANGES: change-set id. */
    val ref: String = ""
)

enum class ChangeStatus { PENDING, APPLIED, REJECTED, UNDONE }

data class FileChange(val path: String, val oldContent: String?, val newContent: String)

data class ChangeSet(
    val id: String,
    val projectId: String,
    val files: List<FileChange>,
    val status: ChangeStatus,
    val summary: String
)

enum class Mode { SINGLE, TEAM }

data class AppSettings(
    val keys: List<String> = List(4) { "" },
    val models: List<String> = List(4) { DEFAULT_MODEL },
    val singleModel: String = DEFAULT_MODEL,
    val mode: Mode = Mode.SINGLE,
    val maxRetries: Int = 3
) {
    /** If a slot has no key, fall back to the first key that is filled in. */
    fun keyFor(slot: Int): String =
        keys.getOrElse(slot) { "" }.trim().ifBlank { keys.firstOrNull { it.isNotBlank() }?.trim() ?: "" }

    fun hasAnyKey(): Boolean = keys.any { it.isNotBlank() }
}

enum class StageState { WAIT, RUN, DONE, FAIL }

data class Stage(val name: String, val state: StageState, val note: String = "")
