package com.techcode.agent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Simple JSON-file persistence. Everything stays on the phone. */
class Store(ctx: Context) {
    private val dir: File = ctx.filesDir
    private val prefs = ctx.getSharedPreferences("techcode", Context.MODE_PRIVATE)

    private fun read(name: String): String? {
        val f = File(dir, name)
        return if (f.exists()) f.readText() else null
    }

    private fun write(name: String, text: String) {
        File(dir, name).writeText(text)
    }

    // ---------- settings ----------

    fun loadSettings(): AppSettings {
        val keys = List(4) { prefs.getString("key$it", "") ?: "" }
        val models = List(4) { prefs.getString("model$it", DEFAULT_MODEL) ?: DEFAULT_MODEL }
        val mode = if (prefs.getString("mode", "SINGLE") == "TEAM") Mode.TEAM else Mode.SINGLE
        return AppSettings(
            keys = keys,
            models = models,
            singleModel = prefs.getString("singleModel", DEFAULT_MODEL) ?: DEFAULT_MODEL,
            mode = mode,
            maxRetries = prefs.getInt("retries", 3)
        )
    }

    fun saveSettings(s: AppSettings) {
        val e = prefs.edit()
        s.keys.forEachIndexed { i, k -> e.putString("key$i", k) }
        s.models.forEachIndexed { i, m -> e.putString("model$i", m) }
        e.putString("singleModel", s.singleModel)
        e.putString("mode", s.mode.name)
        e.putInt("retries", s.maxRetries)
        e.apply()
    }

    fun lastProjectId(): String? = prefs.getString("lastProject", null)
    fun saveLastProjectId(id: String?) {
        val e = prefs.edit()
        if (id == null) e.remove("lastProject") else e.putString("lastProject", id)
        e.apply()
    }

    // ---------- projects ----------

    fun loadProjects(): List<Project> {
        val arr = JSONArray(read("projects.json") ?: "[]")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Project(o.getString("id"), o.getString("name"), o.getString("uri"), o.optLong("at"))
        }
    }

    fun saveProjects(list: List<Project>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("uri", it.folderUri).put("at", it.createdAt))
        }
        write("projects.json", arr.toString())
    }

    // ---------- chats ----------

    fun loadChats(): List<Chat> {
        val arr = JSONArray(read("chats.json") ?: "[]")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Chat(o.getString("id"), o.getString("pid"), o.optString("title", "New chat"), o.optLong("at"))
        }
    }

    fun saveChats(list: List<Chat>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("pid", it.projectId).put("title", it.title).put("at", it.updatedAt))
        }
        write("chats.json", arr.toString())
    }

    fun loadItems(chatId: String): List<ChatItem> {
        val arr = JSONArray(read("chat_$chatId.json") ?: "[]")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            ChatItem(
                id = o.getString("id"),
                kind = runCatching { Kind.valueOf(o.getString("kind")) }.getOrDefault(Kind.AI),
                text = o.optString("text"),
                sub = o.optString("sub"),
                ref = o.optString("ref")
            )
        }
    }

    fun saveItems(chatId: String, items: List<ChatItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("kind", it.kind.name).put("text", it.text)
                    .put("sub", it.sub).put("ref", it.ref)
            )
        }
        write("chat_$chatId.json", arr.toString())
    }

    fun deleteChatFile(chatId: String) {
        File(dir, "chat_$chatId.json").delete()
    }

    // ---------- change sets ----------

    fun saveChangeSet(cs: ChangeSet) {
        val files = JSONArray()
        cs.files.forEach {
            val o = JSONObject().put("path", it.path).put("new", it.newContent)
            if (it.oldContent == null) o.put("old", JSONObject.NULL) else o.put("old", it.oldContent)
            files.put(o)
        }
        val root = JSONObject().put("id", cs.id).put("pid", cs.projectId).put("status", cs.status.name)
            .put("summary", cs.summary).put("files", files)
        write("cs_${cs.id}.json", root.toString())
    }

    fun loadChangeSet(id: String): ChangeSet? {
        val text = read("cs_$id.json") ?: return null
        val o = JSONObject(text)
        val arr = o.getJSONArray("files")
        val files = (0 until arr.length()).map {
            val f = arr.getJSONObject(it)
            FileChange(f.getString("path"), if (f.isNull("old")) null else f.getString("old"), f.getString("new"))
        }
        return ChangeSet(
            id = o.getString("id"),
            projectId = o.getString("pid"),
            files = files,
            status = runCatching { ChangeStatus.valueOf(o.getString("status")) }.getOrDefault(ChangeStatus.PENDING),
            summary = o.optString("summary")
        )
    }
}
