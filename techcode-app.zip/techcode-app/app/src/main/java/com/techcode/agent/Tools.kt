package com.techcode.agent

import org.json.JSONArray
import org.json.JSONObject

data class Verdict(val ok: Boolean, val issues: List<Issue>)

data class Issue(val file: String, val problem: String, val owner: String)

class ToolContext(
    val role: String,
    val ws: Workspace,
    /** Merge role only: the UI / Logic workspaces to read proposals from. */
    val roleWorkspaces: Map<String, Workspace> = emptyMap()
) {
    @Volatile var verdict: Verdict? = null
    @Volatile var stop: Boolean = false
}

/** What the UI shows for a finished tool call. */
data class ToolOutcome(val response: JSONObject, val label: String, val sub: String)

object Tools {

    private fun str(desc: String) = JSONObject().put("type", "string").put("description", desc)

    private fun decl(name: String, desc: String, props: JSONObject, required: List<String>): JSONObject {
        val params = JSONObject().put("type", "object").put("properties", props)
        if (required.isNotEmpty()) params.put("required", JSONArray(required))
        val d = JSONObject().put("name", name).put("description", desc)
        // Gemini rejects an empty OBJECT schema, so only send parameters when there are any.
        if (props.length() > 0) d.put("parameters", params)
        return d
    }

    private val listFiles = decl(
        "list_files", "List all files in the project (relative paths).", JSONObject(), emptyList()
    )
    private val readFile = decl(
        "read_file", "Read a text file. Always read a file before editing it.",
        JSONObject().put("path", str("Relative path, e.g. src/index.html")), listOf("path")
    )
    private val search = decl(
        "search", "Case-insensitive text search across project files. Returns path:line: text.",
        JSONObject().put("query", str("Text to look for")), listOf("query")
    )
    private val writeFile = decl(
        "write_file", "Create a file or fully replace its content. Staged until the user approves.",
        JSONObject().put("path", str("Relative path")).put("content", str("Complete new file content")),
        listOf("path", "content")
    )
    private val editFile = decl(
        "edit_file",
        "Replace one exact piece of text in a file. old_text must appear exactly once. Staged until the user approves.",
        JSONObject()
            .put("path", str("Relative path"))
            .put("old_text", str("Exact existing text (include enough context to be unique)"))
            .put("new_text", str("Replacement text")),
        listOf("path", "old_text", "new_text")
    )
    private val readProposal = decl(
        "read_proposal",
        "Read the version of a file that the UI or Logic agent proposed.",
        JSONObject()
            .put("role", JSONObject().put("type", "string").put("description", "ui or logic"))
            .put("path", str("Relative path")),
        listOf("role", "path")
    )
    private val reportResult: JSONObject = run {
        val issue = JSONObject().put("type", "object").put(
            "properties",
            JSONObject()
                .put("file", str("File with the problem"))
                .put("problem", str("What is wrong and how to fix it"))
                .put("owner", str("Who should fix it: ui, logic or merge"))
        )
        val props = JSONObject()
            .put("ok", JSONObject().put("type", "boolean").put("description", "true if there are no real problems"))
            .put("issues", JSONObject().put("type", "array").put("items", issue))
        decl(
            "report_result",
            "Final verdict. Call this exactly once when your review is finished.",
            props, listOf("ok")
        )
    }

    private fun wrap(vararg d: JSONObject): JSONArray =
        JSONArray().put(JSONObject().put("functionDeclarations", JSONArray(d.toList())))

    fun readOnly(): JSONArray = wrap(listFiles, readFile, search)
    fun readWrite(): JSONArray = wrap(listFiles, readFile, search, writeFile, editFile)
    fun merger(): JSONArray = wrap(listFiles, readFile, search, writeFile, editFile, readProposal)
    fun verifier(): JSONArray = wrap(listFiles, readFile, search, reportResult)

    private fun res(vararg pairs: Pair<String, Any>): JSONObject {
        val o = JSONObject()
        pairs.forEach { o.put(it.first, it.second) }
        return o
    }

    fun execute(name: String, args: JSONObject, ctx: ToolContext): ToolOutcome {
        val ws = ctx.ws
        return when (name) {
            "list_files" -> {
                val all = ws.allFiles()
                ToolOutcome(res("files" to all.joinToString("\n").ifEmpty { "(empty project)" }), "Listed files", "${all.size} files")
            }

            "read_file" -> {
                val path = args.optString("path")
                val text = if (isTextPath(path)) ws.read(path) else null
                if (text == null) {
                    ToolOutcome(res("error" to "File nahi mili ya text file nahi hai: $path"), "Read failed", path)
                } else {
                    val shown = if (text.length > 60_000) text.take(60_000) + "\n...[truncated]" else text
                    ToolOutcome(res("content" to shown), "Read", normPath(path))
                }
            }

            "search" -> {
                val q = args.optString("query")
                val hits = ws.search(q)
                ToolOutcome(res("matches" to hits.joinToString("\n").ifEmpty { "no matches" }), "Searched", q)
            }

            "write_file" -> {
                val path = args.optString("path")
                val content = args.optString("content")
                if (normPath(path).isEmpty() || normPath(path).contains("..")) {
                    ToolOutcome(res("error" to "Invalid path"), "Write failed", path)
                } else {
                    val existed = ws.read(path) != null
                    ws.write(path, content)
                    ToolOutcome(
                        res("result" to "staged ${normPath(path)} (${content.split("\n").size} lines)"),
                        if (existed) "Rewrote" else "Created", normPath(path)
                    )
                }
            }

            "edit_file" -> {
                val path = args.optString("path")
                val old = args.optString("old_text")
                val new = args.optString("new_text")
                val cur = ws.read(path)
                when {
                    cur == null -> ToolOutcome(res("error" to "File nahi mili: $path. Naya file banana ho to write_file use karo."), "Edit failed", path)
                    old.isEmpty() -> ToolOutcome(res("error" to "old_text khaali hai"), "Edit failed", path)
                    else -> {
                        val first = cur.indexOf(old)
                        if (first < 0) {
                            ToolOutcome(res("error" to "old_text file mein nahi mila. File dobara read karo aur exact text do."), "Edit failed", path)
                        } else if (cur.indexOf(old, first + 1) >= 0) {
                            ToolOutcome(res("error" to "old_text ek se zyada jagah mila. Thoda aur context add karo."), "Edit failed", path)
                        } else {
                            ws.write(path, cur.substring(0, first) + new + cur.substring(first + old.length))
                            ToolOutcome(res("result" to "staged edit in ${normPath(path)}"), "Edited", normPath(path))
                        }
                    }
                }
            }

            "read_proposal" -> {
                val role = args.optString("role").lowercase()
                val path = args.optString("path")
                val other = ctx.roleWorkspaces[role]
                val text = other?.proposals()?.get(normPath(path))
                if (text == null) {
                    ToolOutcome(res("error" to "$role ne $path propose nahi kiya"), "Read failed", path)
                } else {
                    ToolOutcome(res("content" to text), "Read ${role.uppercase()} version", normPath(path))
                }
            }

            "report_result" -> {
                val ok = args.optBoolean("ok", false)
                val arr = args.optJSONArray("issues") ?: JSONArray()
                val issues = (0 until arr.length()).mapNotNull {
                    val o = arr.optJSONObject(it) ?: return@mapNotNull null
                    Issue(o.optString("file"), o.optString("problem"), o.optString("owner").lowercase())
                }
                ctx.verdict = Verdict(ok && issues.isEmpty(), issues)
                ctx.stop = true
                ToolOutcome(res("result" to "recorded"), if (ok && issues.isEmpty()) "Verified OK" else "Issues found", "${issues.size} issues")
            }

            else -> ToolOutcome(res("error" to "Unknown tool: $name"), "Unknown tool", name)
        }
    }
}
