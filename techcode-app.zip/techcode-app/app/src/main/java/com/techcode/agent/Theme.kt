package com.techcode.agent

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object TC {
    val Blue = Color(0xFF0A6CFF)
    val Navy = Color(0xFF0A1F8F)
    val Cyan = Color(0xFF22D3FF)
    val Card = Color(0xFFF4F8FF)
    val Soft = Color(0xFFEEF4FF)
    val Border = Color(0xFFDCE8FF)
    val BorderStrong = Color(0xFFC9DBFF)
    val Text = Color(0xFF0F172A)
    val Muted = Color(0xFF475569)
    val Green = Color(0xFF047857)
    val Red = Color(0xFFB91C1C)
    val RedSoft = Color(0xFFFDECEC)
    val AddBg = Color(0xFFE6F6EC)
    val AddFg = Color(0xFF065F46)
    val DelBg = Color(0xFFFDECEC)
    val DelFg = Color(0xFF991B1B)
    val CodeBg = Color(0xFF0B1537)
    val CodeFg = Color(0xFFE6EEFF)
}

@Composable
fun TechCodeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = TC.Blue,
            onPrimary = Color.White,
            primaryContainer = TC.Soft,
            onPrimaryContainer = TC.Navy,
            secondary = TC.Navy,
            background = Color.White,
            onBackground = TC.Text,
            surface = Color.White,
            onSurface = TC.Text,
            surfaceVariant = TC.Card,
            onSurfaceVariant = TC.Muted,
            outline = TC.BorderStrong,
            error = TC.Red
        ),
        content = content
    )
}
