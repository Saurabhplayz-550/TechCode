package com.techcode.agent

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject

fun userContent(text: String): JSONObject =
    JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text)))

/** One agent: calls the model, runs the tools it asks for, repeats until it answers in plain text. */
class AgentRunner(
    private val client: GeminiClient,
    private val system: String,
    private val tools: JSONArray?,
    private val ctx: ToolContext,
    private val onTool: (ToolOutcome) -> Unit,
    private val maxSteps: Int = 30
) {
    suspend fun run(task: String): String {
        val contents = JSONArray().put(userContent(task))
        var finalText = ""
        for (step in 0 until maxSteps) {
            currentCoroutineContext().ensureActive()
            val content = client.generate(system, contents, tools)
            contents.put(content)

            val parts = content.optJSONArray("parts") ?: JSONArray()
            val calls = ArrayList<JSONObject>()
            val text = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (p.has("functionCall")) {
                    calls.add(p.getJSONObject("functionCall"))
                } else if (p.has("text") && !p.optBoolean("thought", false)) {
                    text.append(p.getString("text"))
                }
            }
            if (text.isNotBlank()) finalText = text.toString().trim()
            if (calls.isEmpty()) return finalText

            val responses = JSONArray()
            for (c in calls) {
                val name = c.getString("name")
                val args = c.optJSONObject("args") ?: JSONObject()
                val outcome = Tools.execute(name, args, ctx)
                onTool(outcome)
                responses.put(
                    JSONObject().put(
                        "functionResponse",
                        JSONObject().put("name", name).put("response", outcome.response)
                    )
                )
            }
            if (ctx.stop) return finalText
            contents.put(JSONObject().put("role", "user").put("parts", responses))
        }
        return finalText.ifBlank { "Step limit pahunch gaya, kaam adhoora ho sakta hai." }
    }
}
