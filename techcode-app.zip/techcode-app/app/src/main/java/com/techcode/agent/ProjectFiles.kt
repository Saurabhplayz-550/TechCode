package com.techcode.agent

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

fun normPath(p: String): String =
    p.trim().replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." }.joinToString("/")

private val BINARY_EXT = setOf(
    "png", "jpg", "jpeg", "gif", "webp", "bmp", "ico", "apk", "aab", "zip", "jar", "gz", "tar", "7z",
    "ttf", "otf", "woff", "woff2", "mp3", "mp4", "wav", "ogg", "mkv", "avi", "pdf", "so", "class", "dex", "keystore"
)

fun isTextPath(path: String): Boolean = path.substringAfterLast('.', "").lowercase() !in BINARY_EXT

/** Access to the folder the user picked, through Android's Storage Access Framework. */
class ProjectFiles(private val ctx: Context, treeUri: Uri) {
    private val root: DocumentFile =
        DocumentFile.fromTreeUri(ctx, treeUri) ?: throw IllegalStateException("Folder open nahi ho raha")

    val folderName: String get() = root.name ?: "folder"

    fun canAccess(): Boolean = root.exists() && root.canRead()

    private fun parts(path: String): List<String> = normPath(path).split('/').filter { it.isNotEmpty() }

    private fun find(path: String): DocumentFile? {
        var cur: DocumentFile = root
        for (p in parts(path)) {
            if (p == "..") return null
            cur = cur.findFile(p) ?: return null
        }
        return cur
    }

    fun readText(path: String): String? {
        val f = find(path) ?: return null
        if (!f.isFile) return null
        return ctx.contentResolver.openInputStream(f.uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
    }

    fun writeText(path: String, content: String): Boolean {
        val ps = parts(path)
        if (ps.isEmpty() || ps.contains("..")) return false
        var cur: DocumentFile = root
        for (d in ps.dropLast(1)) {
            cur = cur.findFile(d) ?: cur.createDirectory(d) ?: return false
        }
        val name = ps.last()
        // octet-stream keeps the exact file name (text/plain can make some providers append .txt)
        val target = cur.findFile(name) ?: cur.createFile("application/octet-stream", name) ?: return false
        val out = ctx.contentResolver.openOutputStream(target.uri, "wt") ?: return false
        out.use { it.write(content.toByteArray(Charsets.UTF_8)) }
        return true
    }

    fun delete(path: String): Boolean = find(path)?.delete() ?: false

    private val skipDirs = setOf(".git", "node_modules", "build", ".gradle", ".idea", "__pycache__", ".dart_tool", ".next")

    fun listAll(limit: Int = 400): List<String> {
        val out = ArrayList<String>()
        fun walk(dir: DocumentFile, prefix: String, depth: Int) {
            if (out.size >= limit || depth > 8) return
            val children = dir.listFiles().sortedWith(compareBy({ !it.isDirectory }, { it.name ?: "" }))
            for (c in children) {
                val name = c.name ?: continue
                if (c.isDirectory) {
                    if (name !in skipDirs) walk(c, "$prefix$name/", depth + 1)
                } else {
                    out.add("$prefix$name")
                    if (out.size >= limit) return
                }
            }
        }
        walk(root, "", 0)
        return out
    }
}
