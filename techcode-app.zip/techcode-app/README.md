# TechCode (testing build 0.1.0)

Android pe AI coding agent. Project = ek folder + uske chats. AI us folder ke andar files padhta aur badalta hai, tum diff dekh ke Approve ya Reject karte ho.

## Features
- Projects (folder access, Android Storage Access Framework) aur har project ke andar chats
- Agent tools: list, read, search, edit, write (sab staged, tumhare approve karne tak file nahi badalti)
- Diff viewer, Approve / Reject, Undo
- Single mode (ek model, kabhi bhi switch) aur Team mode (UI + Logic parallel, Merge, Verify; galti mile to owner ke paas wapas, max retries setting se)
- 4 Gemini API keys (Settings), authentication abhi nahi
- `TECHCODE.md` (ya `CLAUDE.md`) project folder mein rakho to AI har baar padhega

## APK banana (GitHub Actions)
1. Is folder ko GitHub repo mein push karo (Termux: `git init && git add . && git commit -m init && git push`).
2. Repo ke **Actions** tab mein "Build APK" chalao (push pe apne aap chalta hai).
3. Run khatam hone pe **Artifacts** se `TechCode-debug-apk` download karo aur install karo.

## Abhi ki limits
- Agent code run ya compile nahi kar sakta.
- Folder Android ke "Download" ya storage root ka nahi chun sakte, uske andar ka koi folder chuno.
- Team mode mein 4 models ek saath chalte hain, free tier pe rate limit (429) jaldi aa sakti hai.
- Code abhi compile karke test nahi hua, pehli build mein error aaye to log bhej dena.
